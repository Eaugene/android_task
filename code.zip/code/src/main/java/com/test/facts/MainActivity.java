package com.test.facts;

import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.*;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
int imgno[]={R.drawable.a0,R.drawable.a1,R.drawable.a2,R.drawable.a3,R.drawable.a4,R.drawable.a5,R.drawable.a6,R.drawable.a7,R.drawable.a8,R.drawable.a9,R.drawable.a10,R.drawable.a11,R.drawable.a12,R.drawable.a13,R.drawable.a14,R.drawable.a15,R.drawable.a16,R.drawable.a17,R.drawable.a18,R.drawable.a19,R.drawable.a20,R.drawable.a21,R.drawable.a22};
   int count=imgno.length;
    int current;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button nextImage=(Button)findViewById(R.id.btnNext);
        final ImageSwitcher imageSwitcher=(ImageSwitcher)findViewById(R.id.imageChanger);
        imageSwitcher.setFactory(new ViewSwitcher.ViewFactory() {
            @Override
            public View makeView() {
                ImageView imageView=new ImageView(getApplicationContext());
                imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
                imageView.setLayoutParams(new ImageSwitcher.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                current=randInt();
                imageView.setImageResource(imgno[current]);
                return imageView;
            }
        });
        final Animation in= AnimationUtils.loadAnimation(this,android.R.anim.slide_in_left);
        final Animation out= AnimationUtils.loadAnimation(this,android.R.anim.slide_out_right);
        imageSwitcher.setInAnimation(in);
        imageSwitcher.setOutAnimation(out);
        nextImage.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                current=randInt();
                imageSwitcher.setImageResource(imgno[current]);
            }
        });
    }
    public static int randInt() {

        Random rand = new Random();

        int randomNum = rand.nextInt((22 - 0) + 1) + 0;

        return randomNum;
    }
}
